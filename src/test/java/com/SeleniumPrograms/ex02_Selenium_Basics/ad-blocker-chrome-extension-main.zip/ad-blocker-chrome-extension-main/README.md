# ad-blocker-chrome-extension
This ad blocker can block all ads on any website without getting detected

![adblocker](https://user-images.githubusercontent.com/66416000/153356426-95893fa9-e7a6-4b59-b4b5-5c1b0e665c87.jpg)

How to use it?
<ul>
  <li>Download this repo as a ZIP file from GitHub.</li>
  <li>Unzip the file.</li>
  <li>In Chrome go to the extensions page (chrome://extensions).</li>
  <li>Enable Developer Mode.</li>
  <li>Click on "Load Unpacked" button and select the folder where you extracted the Zip to import it</li>
  <li>That's all</li>
</ul>





